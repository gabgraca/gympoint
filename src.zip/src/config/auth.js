export default {
  secret: 'c770c461a548d118c32af61fa0199360',
  expiresIn: '7d',
};

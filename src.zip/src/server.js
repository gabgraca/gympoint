// Servidor da aplicação inicia por aqui
import App from './app';

// Inicia os servidor backend na porta http 3334
App.listen(3334);
